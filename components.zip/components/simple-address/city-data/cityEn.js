/* eslint-disable */
var Data = [
	[{
		"label": "City",
		"value": "1101"
	}],
	[{
		"label": "City",
		"value": "1201"
	}],
	[{
			"label": "Shijiazhuang",
			"value": "1301"
		},
		{
			"label": "Tangshan",
			"value": "1302"
		},
		{
			"label": "Qinhuangdao ",
			"value": "1303"
		},
		{
			"label": "Handan ",
			"value": "1304"
		},
		{
			"label": "Xingtai ",
			"value": "1305"
		},
		{
			"label": "Baoding ",
			"value": "1306"
		},
		{
			"label": "Zhangjiakou ",
			"value": "1307"
		},
		{
			"label": "Chengde ",
			"value": "1308"
		},
		{
			"label": "Cangzhou ",
			"value": "1309"
		},
		{
			"label": "Langfang ",
			"value": "1310"
		},
		{
			"label": "Hengshui ",
			"value": "1311"
		}
	],
	[{
			"label": "Taiyuan ",
			"value": "1401"
		},
		{
			"label": "Datong ",
			"value": "1402"
		},
		{
			"label": "Yangquan ",
			"value": "1403"
		},
		{
			"label": "Changzhi ",
			"value": "1404"
		},
		{
			"label": "Jincheng",
			"value": "1405"
		},
		{
			"label": "Shuozhou",
			"value": "1406"
		},
		{
			"label": "Jinzhong ",
			"value": "1407"
		},
		{
			"label": "Yun ",
			"value": "1408"
		},
		{
			"label": "Xinzhou ",
			"value": "1409"
		},
		{
			"label": "Linfen ",
			"value": "1410"
		},
		{
			"label": "Luliang",
			"value": "1411"
		}
	],
	[{
			"label": "Hohhot ",
			"value": "1501"
		},
		{
			"label": "Baotou ",
			"value": "1502"
		},
		{
			"label": "Wuhai ",
			"value": "1503"
		},
		{
			"label": "Chifeng ",
			"value": "1504"
		},
		{
			"label": "Tongliao ",
			"value": "1505"
		},
		{
			"label": "Ordos ",
			"value": "1506"
		},
		{
			"label": "Hulunbuir ",
			"value": "1507"
		},
		{
			"label": "Bayannur ",
			"value": "1508"
		},
		{
			"label": "Ulanchabu ",
			"value": "1509"
		},
		{
			"label": "Xing'an League",
			"value": "1522"
		},
		{
			"label": "Xilin Gol League",
			"value": "1525"
		},
		{
			"label": "Alxa League",
			"value": "1529"
		}
	],
	[{
			"label": "Shenyang ",
			"value": "2101"
		},
		{
			"label": "Dalian ",
			"value": "2102"
		},
		{
			"label": "Anshan ",
			"value": "2103"
		},
		{
			"label": "Fushun ",
			"value": "2104"
		},
		{
			"label": "Benxi ",
			"value": "2105"
		},
		{
			"label": "Dandong ",
			"value": "2106"
		},
		{
			"label": "Jinzhou",
			"value": "2107"
		},
		{
			"label": "Yingkou ",
			"value": "2108"
		},
		{
			"label": "Fuxin ",
			"value": "2109"
		},
		{
			"label": "Liaoyang ",
			"value": "2110"
		},
		{
			"label": "Panjin ",
			"value": "2111"
		},
		{
			"label": "Tieling ",
			"value": "2112"
		},
		{
			"label": "Chaoyang ",
			"value": "2113"
		},
		{
			"label": "Huludao ",
			"value": "2114"
		}
	],
	[{
			"label": "Changchun ",
			"value": "2201"
		},
		{
			"label": "Jilin ",
			"value": "2202"
		},
		{
			"label": "Siping ",
			"value": "2203"
		},
		{
			"label": "Liaoyuan ",
			"value": "2204"
		},
		{
			"label": "Tonghua ",
			"value": "2205"
		},
		{
			"label": "Baishan ",
			"value": "2206"
		},
		{
			"label": "Songyuan",
			"value": "2207"
		},
		{
			"label": "Baicheng",
			"value": "2208"
		},
		{
			"label": "Yanbian Korean Autonomous Prefecture",
			"value": "2224"
		}
	],
	[{
			"label": "Harbin ",
			"value": "2301"
		},
		{
			"label": "Qiqihar ",
			"value": "2302"
		},
		{
			"label": "Jixi ",
			"value": "2303"
		},
		{
			"label": "Hegang ",
			"value": "2304"
		},
		{
			"label": "Shuangyashan ",
			"value": "2305"
		},
		{
			"label": "Daqing ",
			"value": "2306"
		},
		{
			"label": "Yichun ",
			"value": "2307"
		},
		{
			"label": "Jiamusi ",
			"value": "2308"
		},
		{
			"label": "Qitaihe ",
			"value": "2309"
		},
		{
			"label": "Mudanjiang ",
			"value": "2310"
		},
		{
			"label": "Heihe ",
			"value": "2311"
		},
		{
			"label": "Suihua ",
			"value": "2312"
		},
		{
			"label": "Daxinganling Area",
			"value": "2327"
		}
	],
	[{
		"label": " District",
		"value": "3101"
	}],
	[{
			"label": "Nanjing ",
			"value": "3201"
		},
		{
			"label": "Wuxi ",
			"value": "3202"
		},
		{
			"label": "Xuzhou ",
			"value": "3203"
		},
		{
			"label": "Changzhou",
			"value": "3204"
		},
		{
			"label": "Suzhou ",
			"value": "3205"
		},
		{
			"label": "Nantong ",
			"value": "3206"
		},
		{
			"label": "Lianyungang ",
			"value": "3207"
		},
		{
			"label": "Huai'an ",
			"value": "3208"
		},
		{
			"label": "Yancheng",
			"value": "3209"
		},
		{
			"label": "Yangzhou",
			"value": "3210"
		},
		{
			"label": "Zhenjiang ",
			"value": "3211"
		},
		{
			"label": "Taizhou ",
			"value": "3212"
		},
		{
			"label": "Suqian ",
			"value": "3213"
		}
	],
	[{
			"label": "Hangzhou ",
			"value": "3301"
		},
		{
			"label": "Ningbo ",
			"value": "3302"
		},
		{
			"label": "Wenzhou",
			"value": "3303"
		},
		{
			"label": "Jiaxing ",
			"value": "3304"
		},
		{
			"label": "Huzhou ",
			"value": "3305"
		},
		{
			"label": "Shaoxing ",
			"value": "3306"
		},
		{
			"label": "Jinhua ",
			"value": "3307"
		},
		{
			"label": "Quzhou",
			"value": "3308"
		},
		{
			"label": "Zhoushan ",
			"value": "3309"
		},
		{
			"label": "Taizhou",
			"value": "3310"
		},
		{
			"label": "Lishui ",
			"value": "3311"
		}
	],
	[{
			"label": "Hefei ",
			"value": "3401"
		},
		{
			"label": "Wuhu ",
			"value": "3402"
		},
		{
			"label": "Bengbu ",
			"value": "3403"
		},
		{
			"label": "Huainan ",
			"value": "3404"
		},
		{
			"label": "Ma'anshan ",
			"value": "3405"
		},
		{
			"label": "Huaibei ",
			"value": "3406"
		},
		{
			"label": "Tongling ",
			"value": "3407"
		},
		{
			"label": "Anqing ",
			"value": "3408"
		},
		{
			"label": "Huangshan ",
			"value": "3410"
		},
		{
			"label": "Chuzhou ",
			"value": "3411"
		},
		{
			"label": "Fuyang ",
			"value": "3412"
		},
		{
			"label": "Suzhou ",
			"value": "3413"
		},
		{
			"label": "Lu'an ",
			"value": "3415"
		},
		{
			"label": "Bozhou ",
			"value": "3416"
		},
		{
			"label": "Chizhou",
			"value": "3417"
		},
		{
			"label": "Xuancheng",
			"value": "3418"
		}
	],
	[{
			"label": "Fuzhou",
			"value": "3501"
		},
		{
			"label": "Xiamen ",
			"value": "3502"
		},
		{
			"label": "Putian ",
			"value": "3503"
		},
		{
			"label": "Sanming ",
			"value": "3504"
		},
		{
			"label": "Quanzhou",
			"value": "3505"
		},
		{
			"label": "Zhangzhou",
			"value": "3506"
		},
		{
			"label": "Nanping ",
			"value": "3507"
		},
		{
			"label": "Longyan ",
			"value": "3508"
		},
		{
			"label": "Ningde ",
			"value": "3509"
		}
	],
	[{
			"label": "Nanchang ",
			"value": "3601"
		},
		{
			"label": "Jingdezhen ",
			"value": "3602"
		},
		{
			"label": "Pingxiang ",
			"value": "3603"
		},
		{
			"label": "Jiujiang ",
			"value": "3604"
		},
		{
			"label": "Xinyu ",
			"value": "3605"
		},
		{
			"label": "Yingtan ",
			"value": "3606"
		},
		{
			"label": "Ganzhou",
			"value": "3607"
		},
		{
			"label": "Ji'an ",
			"value": "3608"
		},
		{
			"label": "Yichun ",
			"value": "3609"
		},
		{
			"label": "Fuzhou",
			"value": "3610"
		},
		{
			"label": "Shangrao ",
			"value": "3611"
		}
	],
	[{
			"label": "Jinan ",
			"value": "3701"
		},
		{
			"label": "Qingdao ",
			"value": "3702"
		},
		{
			"label": "Zibo ",
			"value": "3703"
		},
		{
			"label": "Zaozhuang ",
			"value": "3704"
		},
		{
			"label": "Dongying ",
			"value": "3705"
		},
		{
			"label": "Yantai ",
			"value": "3706"
		},
		{
			"label": "Weifang ",
			"value": "3707"
		},
		{
			"label": "Jining ",
			"value": "3708"
		},
		{
			"label": "Taian ",
			"value": "3709"
		},
		{
			"label": "Weihai ",
			"value": "3710"
		},
		{
			"label": "Rizhao ",
			"value": "3711"
		},
		{
			"label": "Laiwu ",
			"value": "3712"
		},
		{
			"label": "Linyi ",
			"value": "3713"
		},
		{
			"label": "Dezhou",
			"value": "3714"
		},
		{
			"label": "Liaocheng",
			"value": "3715"
		},
		{
			"label": "Binzhou ",
			"value": "3716"
		},
		{
			"label": "Heze ",
			"value": "3717"
		}
	],
	[{
			"label": "Zhengzhou ",
			"value": "4101"
		},
		{
			"label": "Kaifeng ",
			"value": "4102"
		},
		{
			"label": "Luoyang ",
			"value": "4103"
		},
		{
			"label": "Pingdingshan",
			"value": "4104"
		},
		{
			"label": "Anyang ",
			"value": "4105"
		},
		{
			"label": "Hebi ",
			"value": "4106"
		},
		{
			"label": "Xinxiang ",
			"value": "4107"
		},
		{
			"label": "Jiaozuo ",
			"value": "4108"
		},
		{
			"label": "Puyang ",
			"value": "4109"
		},
		{
			"label": "Xuchang ",
			"value": "4110"
		},
		{
			"label": "Luohe ",
			"value": "4111"
		},
		{
			"label": "Sanmenxia ",
			"value": "4112"
		},
		{
			"label": "Nanyang ",
			"value": "4113"
		},
		{
			"label": "Shangqiu ",
			"value": "4114"
		},
		{
			"label": "Xinyang ",
			"value": "4115"
		},
		{
			"label": "Zhoukou ",
			"value": "4116"
		},
		{
			"label": "Zhumadian ",
			"value": "4117"
		},
		{
			"label": "Provincial county-level administrative divisions",
			"value": "4190"
		}
	],
	[{
			"label": "Wuhan ",
			"value": "4201"
		},
		{
			"label": "Huangshi ",
			"value": "4202"
		},
		{
			"label": "Shiyan ",
			"value": "4203"
		},
		{
			"label": "Yichang ",
			"value": "4205"
		},
		{
			"label": "Xiangyang ",
			"value": "4206"
		},
		{
			"label": "Ezhou ",
			"value": "4207"
		},
		{
			"label": "Jingmen ",
			"value": "4208"
		},
		{
			"label": "Xiaogan ",
			"value": "4209"
		},
		{
			"label": "Jingzhou ",
			"value": "4210"
		},
		{
			"label": "Huanggang ",
			"value": "4211"
		},
		{
			"label": "Xianning ",
			"value": "4212"
		},
		{
			"label": "Suizhou",
			"value": "4213"
		},
		{
			"label": "Enshi Tujia and Miao Autonomous Prefecture",
			"value": "4228"
		},
		{
			"label": "Provincial county-level administrative divisions",
			"value": "4290"
		}
	],
	[{
			"label": "Changsha ",
			"value": "4301"
		},
		{
			"label": "Zhuzhou ",
			"value": "4302"
		},
		{
			"label": "Xiangtan ",
			"value": "4303"
		},
		{
			"label": "Hengyang ",
			"value": "4304"
		},
		{
			"label": "Shaoyang ",
			"value": "4305"
		},
		{
			"label": "Yueyang ",
			"value": "4306"
		},
		{
			"label": "Changde ",
			"value": "4307"
		},
		{
			"label": "Zhangjiajie ",
			"value": "4308"
		},
		{
			"label": "Yiyang ",
			"value": "4309"
		},
		{
			"label": "Chenzhou",
			"value": "4310"
		},
		{
			"label": "Yongzhou",
			"value": "4311"
		},
		{
			"label": "Huaihua ",
			"value": "4312"
		},
		{
			"label": "Loudi ",
			"value": "4313"
		},
		{
			"label": "Xiangxi Tujia and Miao Autonomous Prefecture",
			"value": "4331"
		}
	],
	[{
			"label": "Guangzhou ",
			"value": "4401"
		},
		{
			"label": "Shaoguan ",
			"value": "4402"
		},
		{
			"label": "Shenzhen",
			"value": "4403"
		},
		{
			"label": "Zhuhai ",
			"value": "4404"
		},
		{
			"label": "Shantou ",
			"value": "4405"
		},
		{
			"label": "Foshan ",
			"value": "4406"
		},
		{
			"label": "Jiangmen ",
			"value": "4407"
		},
		{
			"label": "Zhanjiang ",
			"value": "4408"
		},
		{
			"label": "Maoming ",
			"value": "4409"
		},
		{
			"label": "Zhaoqing ",
			"value": "4412"
		},
		{
			"label": "Huizhou",
			"value": "4413"
		},
		{
			"label": "Meizhou",
			"value": "4414"
		},
		{
			"label": "Shanwei ",
			"value": "4415"
		},
		{
			"label": "Heyuan ",
			"value": "4416"
		},
		{
			"label": "Yangjiang ",
			"value": "4417"
		},
		{
			"label": "Qingyuan ",
			"value": "4418"
		},
		{
			"label": "Dongguan ",
			"value": "4419"
		},
		{
			"label": "Zhongshan ",
			"value": "4420"
		},
		{
			"label": "Chaozhou",
			"value": "4451"
		},
		{
			"label": "Jieyang ",
			"value": "4452"
		},
		{
			"label": "Yunfu",
			"value": "4453"
		}
	],
	[{
			"label": "Nanning ",
			"value": "4501"
		},
		{
			"label": "Liuzhou",
			"value": "4502"
		},
		{
			"label": "Guilin ",
			"value": "4503"
		},
		{
			"label": "Wuzhou",
			"value": "4504"
		},
		{
			"label": "Beihai",
			"value": "4505"
		},
		{
			"label": "Fangchenggang ",
			"value": "4506"
		},
		{
			"label": "Qinzhou ",
			"value": "4507"
		},
		{
			"label": "Guigang ",
			"value": "4508"
		},
		{
			"label": "Yulin ",
			"value": "4509"
		},
		{
			"label": "Baise ",
			"value": "4510"
		},
		{
			"label": "Hezhou",
			"value": "4511"
		},
		{
			"label": "Hechi ",
			"value": "4512"
		},
		{
			"label": "Laibin ",
			"value": "4513"
		},
		{
			"label": "Chongzuo ",
			"value": "4514"
		}
	],
	[{
			"label": "Haikou ",
			"value": "4601"
		},
		{
			"label": "Sanya ",
			"value": "4602"
		},
		{
			"label": "Sansha ",
			"value": "4603"
		},
		{
			"label": "Danzhou ",
			"value": "4604"
		},
		{
			"label": "Provincial county-level administrative divisions",
			"value": "4690"
		}
	],
	[{
			"label": " District",
			"value": "5001"
		},
		{
			"label": "County",
			"value": "5002"
		}
	],
	[{
			"label": "Chengdu",
			"value": "5101"
		},
		{
			"label": "Zigong ",
			"value": "5103"
		},
		{
			"label": "Panzhihua ",
			"value": "5104"
		},
		{
			"label": "Luzhou ",
			"value": "5105"
		},
		{
			"label": "Deyang ",
			"value": "5106"
		},
		{
			"label": "Mianyang ",
			"value": "5107"
		},
		{
			"label": "Guangyuan ",
			"value": "5108"
		},
		{
			"label": "Suining ",
			"value": "5109"
		},
		{
			"label": "Neijiang ",
			"value": "5110"
		},
		{
			"label": "Leshan ",
			"value": "5111"
		},
		{
			"label": "Nanchong ",
			"value": "5113"
		},
		{
			"label": "Meishan ",
			"value": "5114"
		},
		{
			"label": "Yibin ",
			"value": "5115"
		},
		{
			"label": "Guang'an ",
			"value": "5116"
		},
		{
			"label": "Dazhou",
			"value": "5117"
		},
		{
			"label": "Ya'an ",
			"value": "5118"
		},
		{
			"label": "Bazhong ",
			"value": "5119"
		},
		{
			"label": "Ziyang ",
			"value": "5120"
		},
		{
			"label": "Aba Tibetan and Qiang Autonomous Prefecture",
			"value": "5132"
		},
		{
			"label": "Ganzi Tibetan Autonomous Prefecture",
			"value": "5133"
		},
		{
			"label": "Liangshan Yi Autonomous Prefecture",
			"value": "5134"
		}
	],
	[{
			"label": "Guiyang ",
			"value": "5201"
		},
		{
			"label": "Liupanshui ",
			"value": "5202"
		},
		{
			"label": "Zunyi ",
			"value": "5203"
		},
		{
			"label": "Anshun ",
			"value": "5204"
		},
		{
			"label": "Bijie ",
			"value": "5205"
		},
		{
			"label": "Tongren ",
			"value": "5206"
		},
		{
			"label": "Buyi and Miao Autonomous Prefecture in Southwest Guizhou",
			"value": "5223"
		},
		{
			"label": "Southeast Guizhou Miao and Dong Autonomous Prefecture",
			"value": "5226"
		},
		{
			"label": "Qiannan Buyi and Miao Autonomous Prefecture",
			"value": "5227"
		}
	],
	[{
			"label": "Kunming ",
			"value": "5301"
		},
		{
			"label": "Qujing ",
			"value": "5303"
		},
		{
			"label": "Yuxi ",
			"value": "5304"
		},
		{
			"label": "Baoshan ",
			"value": "5305"
		},
		{
			"label": "Zhaotong ",
			"value": "5306"
		},
		{
			"label": "Lijiang ",
			"value": "5307"
		},
		{
			"label": "Pu'er ",
			"value": "5308"
		},
		{
			"label": "Lincang ",
			"value": "5309"
		},
		{
			"label": "Chuxiong Yi Autonomous Prefecture",
			"value": "5323"
		},
		{
			"label": "Honghe Hani and Yi Autonomous Prefecture",
			"value": "5325"
		},
		{
			"label": "Wenshan Zhuang and Miao Autonomous Prefecture",
			"value": "5326"
		},
		{
			"label": "Xishuangbanna Dai Autonomous Prefecture",
			"value": "5328"
		},
		{
			"label": "Dali Bai Autonomous Prefecture",
			"value": "5329"
		},
		{
			"label": "Dehong Dai and Jingpo Autonomous Prefecture",
			"value": "5331"
		},
		{
			"label": "Nujiang Lisu Autonomous Prefecture",
			"value": "5333"
		},
		{
			"label": "Diqing Tibetan Autonomous Prefecture",
			"value": "5334"
		}
	],
	[{
			"label": "Lhasa ",
			"value": "5401"
		},
		{
			"label": "Shigatse ",
			"value": "5402"
		},
		{
			"label": "Changshi",
			"value": "5403"
		},
		{
			"label": "Nyingchi",
			"value": "5404"
		},
		{
			"label": "Shannan",
			"value": "5405"
		},
		{
			"label": "Naqu area",
			"value": "5424"
		},
		{
			"label": "Ali area",
			"value": "5425"
		}
	],
	[{
			"label": "Xi'an",
			"value": "6101"
		},
		{
			"label": "Tongchuan ",
			"value": "6102"
		},
		{
			"label": "Baoji ",
			"value": "6103"
		},
		{
			"label": "Xianyang ",
			"value": "6104"
		},
		{
			"label": "Weinan ",
			"value": "6105"
		},
		{
			"label": "Yan'an ",
			"value": "6106"
		},
		{
			"label": "Hanzhong ",
			"value": "6107"
		},
		{
			"label": "Yulin ",
			"value": "6108"
		},
		{
			"label": "Ankang ",
			"value": "6109"
		},
		{
			"label": "Shangluo ",
			"value": "6110"
		}
	],
	[{
			"label": "Lanzhou",
			"value": "6201"
		},
		{
			"label": "Jiayuguan ",
			"value": "6202"
		},
		{
			"label": "Jinchang ",
			"value": "6203"
		},
		{
			"label": "Baiyin ",
			"value": "6204"
		},
		{
			"label": "Tianshui ",
			"value": "6205"
		},
		{
			"label": "Wuwei ",
			"value": "6206"
		},
		{
			"label": "Zhangye ",
			"value": "6207"
		},
		{
			"label": "Pingliang ",
			"value": "6208"
		},
		{
			"label": "Jiuquan ",
			"value": "6209"
		},
		{
			"label": "Qingyang ",
			"value": "6210"
		},
		{
			"label": "Dingxi ",
			"value": "6211"
		},
		{
			"label": "Longnan ",
			"value": "6212"
		},
		{
			"label": "Linxia Hui Autonomous Prefecture",
			"value": "6229"
		},
		{
			"label": "Gannan Tibetan Autonomous Prefecture",
			"value": "6230"
		}
	],
	[{
			"label": "Xining ",
			"value": "6301"
		},
		{
			"label": "Haidong ",
			"value": "6302"
		},
		{
			"label": "Haibei Tibetan Autonomous Prefecture",
			"value": "6322"
		},
		{
			"label": "Huangnan Tibetan Autonomous Prefecture",
			"value": "6323"
		},
		{
			"label": "Hainan Tibetan Autonomous Prefecture",
			"value": "6325"
		},
		{
			"label": "Guoluo Tibetan Autonomous Prefecture",
			"value": "6326"
		},
		{
			"label": "Yushu Tibetan Autonomous Prefecture",
			"value": "6327"
		},
		{
			"label": "Haixi Mongolian and Tibetan Autonomous Prefecture",
			"value": "6328"
		}
	],
	[{
			"label": "Yinchuan ",
			"value": "6401"
		},
		{
			"label": "Shizuishan ",
			"value": "6402"
		},
		{
			"label": "Wuzhong ",
			"value": "6403"
		},
		{
			"label": "Guyuan ",
			"value": "6404"
		},
		{
			"label": "Zhongwei ",
			"value": "6405"
		}
	],
	[{
			"label": "Urumqi ",
			"value": "6501"
		},
		{
			"label": "Karamay ",
			"value": "6502"
		},
		{
			"label": "Turpan ",
			"value": "6504"
		},
		{
			"label": "Hami ",
			"value": "6505"
		},
		{
			"label": "Changji Hui Autonomous Prefecture",
			"value": "6523"
		},
		{
			"label": "Boltala Mongolian Autonomous Prefecture",
			"value": "6527"
		},
		{
			"label": "Bayingoleng Mongolian Autonomous Prefecture",
			"value": "6528"
		},
		{
			"label": "Akesu Area",
			"value": "6529"
		},
		{
			"label": "Kizilsu Kirgiz Autonomous Prefecture",
			"value": "6530"
		},
		{
			"label": "Kashgar area",
			"value": "6531"
		},
		{
			"label": "Hetian area",
			"value": "6532"
		},
		{
			"label": "Ili Kazakh Autonomous Prefecture",
			"value": "6540"
		},
		{
			"label": "Tacheng Area",
			"value": "6542"
		},
		{
			"label": "Altai Region",
			"value": "6543"
		},
		{
			"label": "County-level administrative divisions of autonomous regions",
			"value": "6590"
		}
	],
	[{
			"label": "Taipei",
			"value": "6601"
		},
		{
			"label": "Kaohsiung",
			"value": "6602"
		},
		{
			"label": "Keelung",
			"value": "6603"
		},
		{
			"label": "Taichung",
			"value": "6604"
		},
		{
			"label": "Tainan",
			"value": "6605"
		},
		{
			"label": "Xinzhu",
			"value": "6606"
		},
		{
			"label": "Chiayi",
			"value": "6607"
		},
		{
			"label": "Yilan",
			"value": "6608"
		},
		{
			"label": "Taoyuan",
			"value": "6609"
		},
		{
			"label": "Miaoli",
			"value": "6610"
		},
		{
			"label": "Changhua",
			"value": "6611"
		},
		{
			"label": "Nantou",
			"value": "6612"
		},
		{
			"label": "Yunlin",
			"value": "6613"
		},
		{
			"label": "pingdong",
			"value": "6614"
		},
		{
			"label": "Taitung",
			"value": "6615"
		},
		{
			"label": "Hualien",
			"value": "6616"
		},
		{
			"label": "Penghu",
			"value": "6617"
		}
	],
	[{
			"label": "Hong Kong Island",
			"value": "6701"
		},
		{
			"label": "Kowloon",
			"value": "6702"
		},
		{
			"label": "New Territories",
			"value": "6703"
		}
	],
	[{
			"label": "Macao Peninsula",
			"value": "6801"
		},
		{
			"label": "Taipa Island",
			"value": "6802"
		},
		{
			"label": "Coloane Island",
			"value": "6803"
		},
		{
			"label": "Cotai ",
			"value": "6804"
		}
	],
	[{
		"label": "Diaoyu Island",
		"value": "6901"
	}, ]
]
export default Data;
