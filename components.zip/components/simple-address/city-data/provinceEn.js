/* eslint-disable */
var provinceData = [{
    "label": "Beijing",
    "value": "11"
  },
  {
    "label": "Tianjin",
    "value": "12"
  },
  {
    "label": "Hebei",
    "value": "13"
  },
  {
    "label": "Shanxi",
    "value": "14"
  },
  {
    "label": "Inner Mongolia Autonomous Region",
    "value": "15"
  },
  {
    "label": "Liaoning",
    "value": "21"
  },
  {
    "label": "Jilin",
    "value": "22"
  },
  {
    "label": "Heilongjiang",
    "value": "23"
  },
  {
    "label": "Shanghai",
    "value": "31"
  },
  {
    "label": "Jiangsu",
    "value": "32"
  },
  {
    "label": "Zhejiang",
    "value": "33"
  },
  {
    "label": "Anhui",
    "value": "34"
  },
  {
    "label": "Fujian",
    "value": "35"
  },
  {
    "label": "Jiangxi",
    "value": "36"
  },
  {
    "label": "Shandong",
    "value": "37"
  },
  {
    "label": "Henan",
    "value": "41"
  },
  {
    "label": "Hubei",
    "value": "42"
  },
  {
    "label": "Hunan",
    "value": "43"
  },
  {
    "label": "Guangdong",
    "value": "44"
  },
  {
    "label": "Guangxi Zhuang Autonomous Region",
    "value": "45"
  },
  {
    "label": "Hainan",
    "value": "46"
  },
  {
    "label": "Chongqing",
    "value": "50"
  },
  {
    "label": "Sichuan",
    "value": "51"
  },
  {
    "label": "Guizhou",
    "value": "52"
  },
  {
    "label": "Yunnan",
    "value": "53"
  },
  {
    "label": "Tibet Autonomous Region",
    "value": "54"
  },
  {
    "label": "Shaanxi",
    "value": "61"
  },
  {
    "label": "Gansu",
    "value": "62"
  },
  {
    "label": "Qinghai",
    "value": "63"
  },
  {
    "label": "Ningxia Hui Autonomous Region",
    "value": "64"
  },
  {
    "label": "Xinjiang Uygur Autonomous Region",
    "value": "65"
  },
  {
    "label": "Taiwan",
    "value": "66"
  },
  {
    "label": "Hong Kong",
    "value": "67"
  },
  {
    "label": "Macao",
    "value": "68"
  },
  {
    "label": "Diaoyu Island",
    "value": "69"
  }
]
export default provinceData;